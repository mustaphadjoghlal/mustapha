/* ألواني - واجهة اللوحة */
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var MAXC = 8, KEY = 'alwani.state.v1';
  var inHost = !!window.__adobe_cep__;

  var st = {
    brand: '', tagline: '', lang: 'ar', size: 'slide', theme: 'light', font: '', tpl: 'cols', tones: 7,
    codes: { hex: true, rgb: true, cmyk: true }, contrast: true, swatches: true,
    pages: { cover: true, palette: true, pairs: true },
    main: [], sec: [], secOn: false, logo: null
  };
  var fonts = {};          // family -> {regular, bold}
  var cmyk = {};           // hex -> [c,m,y,k] من الفوتوشوب
  var pageIdx = 0, model = null, busy = false;
  var ERR = {
    NO_DOC: 'افتح مستنداً في الفوتوشوب أولاً', NO_LAYER: 'حدّد طبقة الشعار أولاً', NO_PAGES: 'فعّل صفحة واحدة على الأقل',
    LOGO_SKIPPED: 'تعذّر نسخ الشعار (أبقِ مستند الشعار مفتوحاً)', SWATCH_SKIPPED: 'تعذّرت إضافة بعض الألوان إلى Swatches',
    'EvalScript error.': 'تعذّر تنفيذ الأمر في الفوتوشوب'
  };

  // ---------- الاتصال بالفوتوشوب
  function ascii(s) { return s.replace(/[\u007f-￿]/g, function (c) { return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4); }); }
  function host(fn, args, cb) {
    if (!inHost) { if (cb) cb(null); return; }
    var a = [];
    for (var i = 0; i < (args || []).length; i++) a.push(ascii(JSON.stringify(args[i])));
    window.__adobe_cep__.evalScript(fn + '(' + a.join(',') + ')', function (r) {
      var o;
      try { o = JSON.parse(r); } catch (e) { o = { error: String(r) }; }
      if (o && o.error && ERR[o.error]) o.error = ERR[o.error];
      if (o && o.note && ERR[o.note]) o.note = ERR[o.note];
      if (cb) cb(o);
    });
  }

  // ---------- الحالة
  function save() {
    try { var c = JSON.parse(JSON.stringify(st)); c.logo = null; localStorage.setItem(KEY, JSON.stringify(c)); } catch (e) {}
  }
  function load() {
    try {
      var o = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (!o) return;
      for (var k in st) if (o.hasOwnProperty(k) && k !== 'logo') st[k] = o[k];
    } catch (e) {}
  }
  function status(msg, cls) { var s = $('status'); s.textContent = msg || ''; s.className = 'hint' + (cls ? ' ' + cls : ''); }

  function mk(hex, name) { return { hex: hex, name: name || AC.nameOf(hex, st.lang), auto: !name }; }
  function hexes(list) { var o = []; for (var i = 0; i < list.length; i++) o.push(list[i].hex); return o; }
  function addColors(list, hs) {
    var added = 0;
    for (var i = 0; i < hs.length; i++) {
      var h = AC.normHex(hs[i]);
      if (!h || list.length >= MAXC) continue;
      var dup = false;
      for (var j = 0; j < list.length; j++) if (list[j].hex === h) { dup = true; break; }
      if (!dup) { list.push(mk(h)); added++; }
    }
    return added;
  }

  // ---------- CMYK من إعدادات ألوان الفوتوشوب
  var cmykTimer = null;
  function askCmyk() {
    if (!inHost) return;
    clearTimeout(cmykTimer);
    cmykTimer = setTimeout(function () {
      var need = [], all = hexes(st.main).concat(hexes(st.sec));
      for (var i = 0; i < all.length; i++) if (!cmyk[all[i]]) need.push(all[i].substr(1));
      if (!need.length) return;
      host('alwaniCmyk', [need], function (o) {
        if (!o || o.error || !o.list) return;
        for (var i = 0; i < need.length; i++) if (o.list[i]) cmyk['#' + need[i]] = o.list[i];
        render();
      });
    }, 250);
  }
  function cmykOf(hex) { return cmyk[hex] || AC.naiveCmyk(hex); }

  // ---------- المعاينة
  var mctx = document.createElement('canvas').getContext('2d');
  function fontCss(size, bold) { return (bold ? '700 ' : '400 ') + size + 'px ' + (st.font ? '"' + st.font + '", ' : '') + '"Segoe UI", Tahoma, Arial, sans-serif'; }
  function measure(s, size, bold) { mctx.font = fontCss(100, bold); return mctx.measureText(s).width * size / 100; }

  function rr(ctx, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath();
  }
  function draw() {
    var cv = $('preview'), ctx = cv.getContext('2d');
    var pg = model.pages[pageIdx];
    var s = Math.min(1, 1280 / Math.max(model.W, model.H));
    cv.width = Math.round(model.W * s); cv.height = Math.round(model.H * s);
    ctx.setTransform(s, 0, 0, s, 0, 0);
    ctx.clearRect(0, 0, model.W, model.H);
    if (!pg) return;
    for (var i = 0; i < pg.ops.length; i++) {
      var o = pg.ops[i];
      if (o.t === 'rect') {
        ctx.fillStyle = o.fill;
        if (o.r) { rr(ctx, o.x, o.y, o.w, o.h, o.r); ctx.fill(); } else ctx.fillRect(o.x, o.y, o.w, o.h);
      } else if (o.t === 'text') {
        ctx.fillStyle = o.fill; ctx.font = fontCss(o.size, o.bold); ctx.textAlign = o.align; ctx.textBaseline = 'alphabetic';
        ctx.direction = /[؀-ۿ]/.test(o.s) ? 'rtl' : 'ltr';
        ctx.fillText(o.s, o.x, o.y);
      } else if (o.t === 'logo') {
        ctx.strokeStyle = o.fill; ctx.lineWidth = 2 * model.u; ctx.setLineDash([10 * model.u, 8 * model.u]);
        ctx.strokeRect(o.x, o.y, o.w, o.h); ctx.setLineDash([]);
        ctx.fillStyle = o.fill; ctx.font = fontCss(22 * model.u, false); ctx.textAlign = 'center'; ctx.direction = 'rtl';
        ctx.fillText(o.label, o.x + o.w / 2, o.y + o.h / 2 + 8 * model.u);
      }
    }
  }
  function render() {
    model = AL.build(st, measure, cmykOf);
    if (pageIdx >= model.pages.length) pageIdx = Math.max(0, model.pages.length - 1);
    var tabs = $('tabs'); tabs.innerHTML = '';
    for (var i = 0; i < model.pages.length; i++) (function (i) {
      var b = document.createElement('button');
      b.textContent = model.pages[i].name; if (i === pageIdx) b.className = 'on';
      b.onclick = function () { pageIdx = i; render(); };
      tabs.appendChild(b);
    })(i);
    draw();
    var none = !st.main.length;
    $('emptyStage').hidden = !none;
    $('create').disabled = busy || none || !model.pages.length;
    $('mainCount').textContent = st.main.length ? '(' + st.main.length + ')' : '';
    $('secCount').textContent = st.secOn && st.sec.length ? '(' + st.sec.length + ')' : '';
  }
  function changed() { save(); askCmyk(); render(); }

  // ---------- قوائم الألوان
  function listUI(ul, list) {
    ul.innerHTML = '';
    for (var i = 0; i < list.length; i++) (function (i) {
      var c = list[i], li = document.createElement('li');
      var pick = document.createElement('input'); pick.type = 'color'; pick.value = c.hex.toLowerCase();
      var hx = document.createElement('input'); hx.type = 'text'; hx.className = 'hex'; hx.value = c.hex; hx.maxLength = 7; hx.spellcheck = false;
      var nm = document.createElement('input'); nm.type = 'text'; nm.className = 'nm'; nm.value = c.name; nm.maxLength = 28;
      var x = document.createElement('button'); x.className = 'x'; x.textContent = '✕'; x.title = 'حذف';
      function setHex(h) {
        c.hex = h; hx.value = h; pick.value = h.toLowerCase();
        if (c.auto) { c.name = AC.nameOf(h, st.lang); nm.value = c.name; }
        changed();
      }
      pick.oninput = function () { var h = AC.normHex(pick.value); if (h) setHex(h); };
      hx.onchange = function () { var h = AC.normHex(hx.value); if (h) setHex(h); else hx.value = c.hex; };
      nm.oninput = function () { c.name = nm.value; c.auto = !nm.value; changed(); };
      nm.onblur = function () { if (!nm.value) { c.name = AC.nameOf(c.hex, st.lang); c.auto = true; nm.value = c.name; changed(); } };
      x.onclick = function () { list.splice(i, 1); lists(); changed(); };
      li.appendChild(pick); li.appendChild(hx); li.appendChild(nm); li.appendChild(x);
      ul.appendChild(li);
    })(i);
  }
  function lists() { listUI($('mainList'), st.main); listUI($('secList'), st.sec); $('secBox').hidden = !st.secOn; }

  // ---------- عناصر التحكم
  function seg(id, get, set) {
    var el = $(id), bs = el.getElementsByTagName('button');
    function paint() { for (var i = 0; i < bs.length; i++) bs[i].className = String(get()) === bs[i].getAttribute('data-v') ? 'on' : ''; }
    for (var i = 0; i < bs.length; i++) (function (b) { b.onclick = function () { set(b.getAttribute('data-v')); paint(); changed(); }; })(bs[i]);
    paint();
  }
  function check(id, get, set) { var el = $(id); el.checked = !!get(); el.onchange = function () { set(el.checked); changed(); }; }
  function textIn(id, key) { var el = $(id); el.value = st[key] || ''; el.oninput = function () { st[key] = el.value; changed(); }; }

  function renameAuto() {
    var ls = [st.main, st.sec];
    for (var a = 0; a < 2; a++) for (var i = 0; i < ls[a].length; i++) if (ls[a][i].auto) ls[a][i].name = AC.nameOf(ls[a][i].hex, st.lang);
    lists();
  }

  function fromLayers(list) {
    if (!inHost) { status('يعمل هذا الزر داخل الفوتوشوب', 'err'); return; }
    host('alwaniSelectedColors', [], function (o) {
      if (!o || o.error) { status((o && o.error) || 'تعذّر قراءة الطبقات', 'err'); return; }
      if (!o.list.length) { status('حدّد طبقات أشكال أو نصوص ملوّنة أولاً', 'err'); return; }
      var n = addColors(list, o.list);
      lists(); changed();
      status(n ? 'أُضيف ' + n + ' لون' : 'هذه الألوان موجودة مسبقاً', n ? 'ok' : '');
    });
  }
  function fromImage() {
    if (!inHost) { status('يعمل هذا الزر داخل الفوتوشوب', 'err'); return; }
    status('جارٍ قراءة الصورة…');
    host('alwaniThumb', [], function (o) {
      if (!o || o.error) { status((o && o.error) || 'تعذّر قراءة المستند', 'err'); return; }
      var data = null;
      try { var r = window.cep.fs.readFile(o.path, window.cep.encoding.Base64); if (r.err === 0) data = r.data; } catch (e) {}
      if (!data) { status('تعذّر فتح صورة المعاينة', 'err'); return; }
      var img = new Image();
      img.onload = function () {
        var c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
        var x = c.getContext('2d'); x.drawImage(img, 0, 0);
        var found = AC.dominant(x.getImageData(0, 0, c.width, c.height).data, Math.max(1, Math.min(5, MAXC - st.main.length)));
        var n = addColors(st.main, found);
        lists(); changed();
        status(n ? 'استُخرج ' + n + ' لون من الصورة' : 'لم أجد ألواناً جديدة', n ? 'ok' : '');
      };
      img.onerror = function () { status('تعذّر فتح صورة المعاينة', 'err'); };
      img.src = 'data:image/png;base64,' + data;
    });
  }

  function loadFonts() {
    host('alwaniFonts', [], function (o) {
      if (!o || o.error || !o.list) return;
      var fam = [], i;
      for (i = 0; i < o.list.length; i++) {
        var f = o.list[i], e = fonts[f[0]];
        if (!e) { e = fonts[f[0]] = { regular: null, bold: null, first: f[2], semi: null }; fam.push(f[0]); }
        if (/^(regular|normal|book|roman)$/i.test(f[1])) e.regular = f[2];
        else if (/^bold$/i.test(f[1])) e.bold = f[2];
        else if (/^(semi|demi) ?bold$/i.test(f[1]) && !e.semi) e.semi = f[2];
        else if (/^medium$/i.test(f[1]) && !e.regular) e.regular = f[2];
      }
      fam.sort(function (a, b) { return a.toLowerCase() < b.toLowerCase() ? -1 : 1; });
      var sel = $('font');
      for (i = 0; i < fam.length; i++) { var op = document.createElement('option'); op.value = fam[i]; op.textContent = fam[i]; sel.appendChild(op); }
      if (!st.font || !fonts[st.font]) {
        var pref = ['Tajawal', 'Cairo', 'IBM Plex Sans Arabic', 'Almarai', 'Noto Sans Arabic', 'Segoe UI', 'Tahoma', 'Arial'];
        st.font = '';
        for (i = 0; i < pref.length; i++) if (fonts[pref[i]]) { st.font = pref[i]; break; }
      }
      sel.value = st.font;
      render();
    });
  }

  function create() {
    if (busy || !st.main.length) return;
    var m = AL.build(st, measure, cmykOf), i, j, f = fonts[st.font] || {};
    var pages = [];
    for (i = 0; i < m.pages.length; i++) {
      var ops = [];
      for (j = 0; j < m.pages[i].ops.length; j++) {
        var o = m.pages[i].ops[j], q = { t: o.t, x: Math.round(o.x * 10) / 10, y: Math.round(o.y * 10) / 10 };
        if (o.t === 'text') { q.s = o.s; q.size = Math.round(o.size * 10) / 10; q.fill = o.fill.substr(1); q.align = o.align; q.bold = o.bold ? 1 : 0; }
        else { q.w = Math.round(o.w * 10) / 10; q.h = Math.round(o.h * 10) / 10; q.fill = o.fill.substr(1); q.r = Math.round(o.r || 0); q.name = o.name || ''; if (o.anchor) q.anchor = o.anchor; }
        ops.push(q);
      }
      pages.push({ name: m.pages[i].name, ops: ops });
    }
    var sw = [];
    if (st.swatches) {
      var all = st.main.concat(st.secOn ? st.sec : []);
      for (i = 0; i < all.length; i++) sw.push({ name: (st.brand ? st.brand + ' - ' : '') + all[i].name, hex: all[i].hex.substr(1) });
    }
    var payload = {
      w: m.W, h: m.H, gap: Math.round(120 * m.u), pages: pages, swatches: sw,
      name: (st.brand || 'Alwani') + ' - ' + AL.T[st.lang].guide,
      font: f.regular || f.first || '', fontBold: f.bold || f.semi || f.regular || f.first || '',
      ppi: st.size === 'a4' ? 300 : 72, logo: !!st.logo
    };
    if (!inHost) { status('افتح اللوحة داخل الفوتوشوب لإنشاء المستند', 'err'); return; }
    busy = true; $('create').disabled = true; status('جارٍ إنشاء الدليل… قد يستغرق بضع ثوانٍ');
    setTimeout(function () {
      host('alwaniBuild', [payload], function (o) {
        busy = false; $('create').disabled = false;
        if (!o || o.error) { status('خطأ: ' + ((o && o.error) || 'غير معروف'), 'err'); return; }
        status('تم إنشاء الدليل (' + o.pages + ' صفحات، ' + o.layers + ' طبقة)' + (o.note ? ' - ' + o.note : ''), 'ok');
      });
    }, 60);
  }

  // ---------- التشغيل
  load();
  textIn('brand', 'brand'); textIn('tagline', 'tagline');
  seg('size', function () { return st.size; }, function (v) { st.size = v; });
  seg('theme', function () { return st.theme; }, function (v) { st.theme = v; });
  seg('lang', function () { return st.lang; }, function (v) { st.lang = v; renameAuto(); });
  seg('tpl', function () { return st.tpl; }, function (v) { st.tpl = v; });
  seg('tones', function () { return st.tones; }, function (v) { st.tones = parseInt(v, 10) || 0; });
  check('pgCover', function () { return st.pages.cover; }, function (v) { st.pages.cover = v; });
  check('pgPalette', function () { return st.pages.palette; }, function (v) { st.pages.palette = v; });
  check('pgPairs', function () { return st.pages.pairs; }, function (v) { st.pages.pairs = v; });
  check('cHex', function () { return st.codes.hex; }, function (v) { st.codes.hex = v; });
  check('cRgb', function () { return st.codes.rgb; }, function (v) { st.codes.rgb = v; });
  check('cCmyk', function () { return st.codes.cmyk; }, function (v) { st.codes.cmyk = v; });
  check('contrast', function () { return st.contrast; }, function (v) { st.contrast = v; });
  check('swatches', function () { return st.swatches; }, function (v) { st.swatches = v; });
  check('secOn', function () { return st.secOn; }, function (v) { st.secOn = v; $('secBox').hidden = !v; });

  $('font').onchange = function () { st.font = $('font').value; changed(); };
  $('addMain').onclick = function () { if (st.main.length < MAXC) { st.main.push(mk(st.main.length ? AC.lchToHex(0.62, 0.15, (AC.hexToLch(st.main[st.main.length - 1].hex)[2] + 50) % 360) : '#2E6FE4')); lists(); changed(); } };
  $('addSec').onclick = function () { if (st.sec.length < MAXC) { st.sec.push(mk('#C9CED6')); lists(); changed(); } };
  $('fromLayers').onclick = function () { fromLayers(st.main); };
  $('secLayers').onclick = function () { fromLayers(st.sec); };
  $('fromImage').onclick = fromImage;
  $('fromFg').onclick = function () {
    if (!inHost) { status('يعمل هذا الزر داخل الفوتوشوب', 'err'); return; }
    host('alwaniForeground', [], function (o) { if (o && o.hex) { addColors(st.main, [o.hex]); lists(); changed(); } });
  };
  $('example').onclick = function () {
    st.main = []; addColors(st.main, ['#1F3A5F', '#E4572E', '#F2B33D', '#F4EFE6']);
    if (!st.brand) { st.brand = 'النسيم'; $('brand').value = st.brand; }
    lists(); changed(); status('');
  };
  $('sortMain').onclick = function () { st.main.sort(function (a, b) { return AC.hexToLch(a.hex)[0] - AC.hexToLch(b.hex)[0]; }); lists(); changed(); };
  $('clearMain').onclick = function () { st.main = []; lists(); changed(); };
  $('suggest').onclick = function () {
    if (!st.main.length) { status('أضف الألوان الأساسية أولاً', 'err'); return; }
    var s = AC.suggest(hexes(st.main), hexes(st.sec));
    var n = addColors(st.sec, s); lists(); changed();
    status(n ? 'اقتُرح ' + n + ' لون ثانوي' : 'لا اقتراحات جديدة', n ? 'ok' : '');
  };
  $('logoBtn').onclick = function () {
    if (!inHost) { status('يعمل هذا الزر داخل الفوتوشوب', 'err'); return; }
    host('alwaniSetLogo', [], function (o) {
      if (!o || o.error) { status((o && o.error) || 'حدّد طبقة الشعار أولاً', 'err'); return; }
      st.logo = { name: o.name }; $('logoState').textContent = o.name; $('logoClear').hidden = false; render();
    });
  };
  $('logoClear').onclick = function () { st.logo = null; $('logoState').textContent = 'اختياري'; $('logoClear').hidden = true; host('alwaniClearLogo', []); render(); };
  $('create').onclick = create;

  lists(); render(); askCmyk(); loadFonts();
  window.__alwani = { st: st, render: render, lists: lists };
})();
