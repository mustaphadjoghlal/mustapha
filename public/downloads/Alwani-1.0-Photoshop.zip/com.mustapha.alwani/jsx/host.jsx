/* Alwani - Photoshop host script (ExtendScript, ES3, ASCII only) */

function alCT(s) { return charIDToTypeID(s); }
function alST(s) { return stringIDToTypeID(s); }

function alJSON(v) {
  var t = typeof v, i, a, k;
  if (v === null || v === undefined) return 'null';
  if (t === 'number') return isFinite(v) ? String(v) : 'null';
  if (t === 'boolean') return v ? 'true' : 'false';
  if (t === 'string') {
    var s = '"';
    for (i = 0; i < v.length; i++) {
      var c = v.charCodeAt(i), ch = v.charAt(i);
      if (ch === '"') s += '\\"';
      else if (ch === '\\') s += '\\\\';
      else if (c < 32 || c > 126) { var h = c.toString(16); while (h.length < 4) h = '0' + h; s += '\\u' + h; }
      else s += ch;
    }
    return s + '"';
  }
  if (v instanceof Array) {
    a = [];
    for (i = 0; i < v.length; i++) a.push(alJSON(v[i]));
    return '[' + a.join(',') + ']';
  }
  a = [];
  for (k in v) if (v.hasOwnProperty(k)) a.push(alJSON(String(k)) + ':' + alJSON(v[k]));
  return '{' + a.join(',') + '}';
}
function alErr(e) {
  var m = (e && e.message) ? e.message : String(e);
  return alJSON({ error: m + (e && e.line ? ' (line ' + e.line + ')' : '') });
}
function alHex2(n) { var h = Math.round(Math.max(0, Math.min(255, n))).toString(16).toUpperCase(); return h.length < 2 ? '0' + h : h; }
function alColor(hex) { var c = new SolidColor(); c.rgb.hexValue = hex; return c; }

/* ---------- info / colors ---------- */

function alwaniForeground() {
  try { return alJSON({ hex: app.foregroundColor.rgb.hexValue }); } catch (e) { return alErr(e); }
}

function alwaniCmyk(list) {
  try {
    var out = [], i, c;
    for (i = 0; i < list.length; i++) {
      c = alColor(list[i]);
      out.push([Math.round(c.cmyk.cyan), Math.round(c.cmyk.magenta), Math.round(c.cmyk.yellow), Math.round(c.cmyk.black)]);
    }
    return alJSON({ list: out });
  } catch (e) { return alErr(e); }
}

function alRgbFromDesc(d) {
  /* returns 'RRGGBB' or null (only RGB colors are read) */
  try {
    if (d.hasKey(alCT('Rd  ')) && d.hasKey(alCT('Grn ')) && d.hasKey(alCT('Bl  ')))
      return alHex2(d.getDouble(alCT('Rd  '))) + alHex2(d.getDouble(alCT('Grn '))) + alHex2(d.getDouble(alCT('Bl  ')));
  } catch (e) {}
  return null;
}

function alSelectedIds() {
  var ids = [], ref = new ActionReference(), d, l, i;
  ref.putProperty(alCT('Prpr'), alST('targetLayersIDs'));
  ref.putEnumerated(alCT('Dcmn'), alCT('Ordn'), alCT('Trgt'));
  d = executeActionGet(ref);
  if (d.hasKey(alST('targetLayersIDs'))) {
    l = d.getList(alST('targetLayersIDs'));
    for (i = 0; i < l.count; i++) ids.push(l.getReference(i).getIdentifier());
  }
  return ids;
}

function alwaniSelectedColors() {
  try {
    if (!app.documents.length) return alJSON({ error: 'NO_DOC' });
    var ids = alSelectedIds(), out = [], seen = {}, i, j, ref, d, h;
    function add(x) { if (x && !seen[x]) { seen[x] = 1; out.push(x); } }
    for (i = 0; i < ids.length; i++) {
      try {
        ref = new ActionReference();
        ref.putIdentifier(alCT('Lyr '), ids[i]);
        d = executeActionGet(ref);
        if (d.hasKey(alST('adjustment'))) {
          var adj = d.getList(alST('adjustment'));
          for (j = 0; j < adj.count; j++) {
            if (adj.getObjectType(j) === alST('solidColorLayer')) {
              var sc = adj.getObjectValue(j);
              if (sc.hasKey(alCT('Clr '))) add(alRgbFromDesc(sc.getObjectValue(alCT('Clr '))));
            }
          }
        }
        if (d.hasKey(alST('textKey'))) {
          var tk = d.getObjectValue(alST('textKey'));
          if (tk.hasKey(alST('textStyleRange'))) {
            var rs = tk.getList(alST('textStyleRange'));
            for (j = 0; j < rs.count && j < 20; j++) {
              var ts = rs.getObjectValue(j).getObjectValue(alST('textStyle'));
              if (ts.hasKey(alCT('Clr '))) add(alRgbFromDesc(ts.getObjectValue(alCT('Clr '))));
            }
          }
        }
      } catch (e1) {}
    }
    return alJSON({ list: out });
  } catch (e) { return alErr(e); }
}

/* small merged copy of the open document, saved to the temp folder for palette extraction */
function alwaniThumb() {
  var dup = null, oldUnits = app.preferences.rulerUnits;
  try {
    if (!app.documents.length) return alJSON({ error: 'NO_DOC' });
    app.preferences.rulerUnits = Units.PIXELS;
    dup = app.activeDocument.duplicate('alwani_tmp', true);
    if (dup.mode !== DocumentMode.RGB) dup.changeMode(ChangeMode.RGB);
    if (dup.bitsPerChannel !== BitsPerChannelType.EIGHT) dup.bitsPerChannel = BitsPerChannelType.EIGHT;
    var w = dup.width.as('px'), h = dup.height.as('px'), k = 160 / Math.max(w, h);
    if (k < 1) dup.resizeImage(new UnitValue(Math.max(1, Math.round(w * k)), 'px'), new UnitValue(Math.max(1, Math.round(h * k)), 'px'), null, ResampleMethod.BICUBIC);
    var f = new File(Folder.temp.fsName + '/alwani_thumb.png');
    dup.saveAs(f, new PNGSaveOptions(), true, Extension.LOWERCASE);
    dup.close(SaveOptions.DONOTSAVECHANGES); dup = null;
    app.preferences.rulerUnits = oldUnits;
    return alJSON({ path: f.fsName });
  } catch (e) {
    try { if (dup) dup.close(SaveOptions.DONOTSAVECHANGES); } catch (e2) {}
    app.preferences.rulerUnits = oldUnits;
    return alErr(e);
  }
}

function alwaniFonts() {
  try {
    var out = [], n = app.fonts.length, i, f;
    for (i = 0; i < n; i++) {
      try { f = app.fonts[i]; out.push([f.family, f.style, f.postScriptName]); } catch (e1) {}
    }
    return alJSON({ list: out });
  } catch (e) { return alErr(e); }
}

/* ---------- logo ---------- */

function alwaniSetLogo() {
  try {
    if (!app.documents.length) return alJSON({ error: 'NO_DOC' });
    var doc = app.activeDocument, l = doc.activeLayer;
    if (!l) return alJSON({ error: 'NO_LAYER' });
    $.global.alwaniLogo = { doc: doc.name, id: l.id, name: l.name };
    return alJSON({ name: l.name });
  } catch (e) { return alErr(e); }
}
function alwaniClearLogo() { $.global.alwaniLogo = null; return alJSON({ ok: true }); }

function alSelectById(id) {
  var d = new ActionDescriptor(), r = new ActionReference();
  r.putIdentifier(alCT('Lyr '), id);
  d.putReference(alCT('null'), r);
  d.putBoolean(alCT('MkVs'), false);
  executeAction(alCT('slct'), d, DialogModes.NO);
}

/* ---------- drawing ---------- */

function alMakeArtboard(doc, name, l, t, r, b) {
  var d = new ActionDescriptor(), ref = new ActionReference(), rc = new ActionDescriptor();
  ref.putClass(alST('artboardSection'));
  d.putReference(alCT('null'), ref);
  rc.putDouble(alST('top'), t); rc.putDouble(alST('left'), l);
  rc.putDouble(alST('bottom'), b); rc.putDouble(alST('right'), r);
  d.putObject(alST('artboardRect'), alST('classFloatRect'), rc);
  executeAction(alCT('Mk  '), d, DialogModes.NO);
  var set = doc.activeLayer;
  if (!set || set.typename !== 'LayerSet') throw new Error('artboard');
  set.name = name;
  return set;
}

function alRect(x, y, w, h, hex, radius) {
  var c = alColor(hex);
  var d = new ActionDescriptor(), ref = new ActionReference(), use = new ActionDescriptor();
  var fill = new ActionDescriptor(), rgb = new ActionDescriptor(), shp = new ActionDescriptor();
  ref.putClass(alST('contentLayer'));
  d.putReference(alCT('null'), ref);
  rgb.putDouble(alCT('Rd  '), c.rgb.red); rgb.putDouble(alCT('Grn '), c.rgb.green); rgb.putDouble(alCT('Bl  '), c.rgb.blue);
  fill.putObject(alCT('Clr '), alCT('RGBC'), rgb);
  use.putObject(alCT('Type'), alST('solidColorLayer'), fill);
  shp.putInteger(alST('unitValueQuadVersion'), 1);
  shp.putUnitDouble(alCT('Top '), alCT('#Pxl'), y);
  shp.putUnitDouble(alCT('Left'), alCT('#Pxl'), x);
  shp.putUnitDouble(alCT('Btom'), alCT('#Pxl'), y + h);
  shp.putUnitDouble(alCT('Rght'), alCT('#Pxl'), x + w);
  if (radius > 0) {
    var r = Math.min(radius, w / 2, h / 2);
    shp.putUnitDouble(alST('topRight'), alCT('#Pxl'), r);
    shp.putUnitDouble(alST('topLeft'), alCT('#Pxl'), r);
    shp.putUnitDouble(alST('bottomLeft'), alCT('#Pxl'), r);
    shp.putUnitDouble(alST('bottomRight'), alCT('#Pxl'), r);
  }
  use.putObject(alCT('Shp '), alCT('Rctn'), shp);
  d.putObject(alCT('Usng'), alST('contentLayer'), use);
  executeAction(alCT('Mk  '), d, DialogModes.NO);
}

function alNest(layer, set) {
  try {
    var p = layer.parent;
    if (p && p.typename === 'LayerSet' && p.id === set.id) return;
    layer.move(set, ElementPlacement.INSIDE);
  } catch (e) {}
}

function alText(set, o, ox, P) {
  var l = set.artLayers.add();
  l.kind = LayerKind.TEXT;
  var t = l.textItem;
  t.contents = o.s;
  try { t.font = o.bold ? P.fontBold : P.font; } catch (e1) {}
  if (o.bold && P.fontBold === P.font) { try { t.fauxBold = true; } catch (e2) {} }
  t.size = new UnitValue(Math.max(4, o.size), 'px');
  t.color = alColor(o.fill);
  t.justification = o.align === 'right' ? Justification.RIGHT : o.align === 'center' ? Justification.CENTER : Justification.LEFT;
  t.position = [new UnitValue(ox + o.x, 'px'), new UnitValue(o.y, 'px')];
  try { l.name = o.s.length > 40 ? o.s.substr(0, 40) : o.s; } catch (e3) {}
  return l;
}

function alBounds(l) {
  var b = l.bounds;
  return [b[0].as('px'), b[1].as('px'), b[2].as('px'), b[3].as('px')];
}

function alLogo(doc, set, o, ox) {
  var L = $.global.alwaniLogo, src = null, i;
  if (!L) return false;
  for (i = 0; i < app.documents.length; i++) if (app.documents[i].name === L.doc) { src = app.documents[i]; break; }
  if (!src) return false;
  var before = -1;
  try { before = doc.activeLayer.id; } catch (e0) {}
  app.activeDocument = src;
  alSelectById(L.id);
  src.activeLayer.duplicate(doc, ElementPlacement.PLACEATBEGINNING);
  app.activeDocument = doc;
  var l = doc.activeLayer;
  if (!l || l.id === before) return false; /* the copy did not become the active layer: leave everything untouched */
  var b = alBounds(l), bw = b[2] - b[0], bh = b[3] - b[1];
  if (bw < 1 || bh < 1) return false;
  var k = Math.min(o.w / bw, o.h / bh) * 100;
  l.resize(k, k, AnchorPosition.MIDDLECENTER);
  b = alBounds(l);
  var tx = (o.anchor === 'right') ? (ox + o.x + o.w - b[2]) : (ox + o.x - b[0]);
  l.translate(new UnitValue(tx, 'px'), new UnitValue(o.y - b[1], 'px'));
  try { l.name = 'Logo'; } catch (e) {}
  alNest(l, set);
  return true;
}

function alAddSwatch(name, hex) {
  var c = alColor(hex), d = new ActionDescriptor(), ref = new ActionReference(), sw = new ActionDescriptor(), rgb = new ActionDescriptor();
  ref.putClass(alCT('Clrs'));
  d.putReference(alCT('null'), ref);
  sw.putString(alCT('Nm  '), name);
  rgb.putDouble(alCT('Rd  '), c.rgb.red); rgb.putDouble(alCT('Grn '), c.rgb.green); rgb.putDouble(alCT('Bl  '), c.rgb.blue);
  sw.putObject(alCT('Clr '), alCT('RGBC'), rgb);
  d.putObject(alCT('Usng'), alCT('Clrs'), sw);
  executeAction(alCT('Mk  '), d, DialogModes.NO);
}

function alwaniDraw() {
  var P = $.global.alwaniP, doc = $.global.alwaniDoc, R = $.global.alwaniR;
  var i, j, base = null, artboards = true;
  try { base = doc.activeLayer; } catch (e0) {}
  for (i = 0; i < P.pages.length; i++) {
    var pg = P.pages[i], ox = i * (P.w + P.gap), set = null;
    if (artboards) {
      try { set = alMakeArtboard(doc, pg.name, ox, 0, ox + P.w, P.h); } catch (e1) { artboards = false; set = null; }
    }
    if (!set) { set = doc.layerSets.add(); set.name = pg.name; }
    for (j = 0; j < pg.ops.length; j++) {
      var o = pg.ops[j], layer = null;
      if (o.t === 'rect') {
        doc.activeLayer = set;
        alRect(ox + o.x, o.y, o.w, o.h, o.fill, o.r);
        layer = doc.activeLayer;
        try { if (o.name) layer.name = o.name; } catch (e2) {}
        alNest(layer, set);
        R.layers++;
      } else if (o.t === 'text') {
        alText(set, o, ox, P);
        R.layers++;
      } else if (o.t === 'logo' && P.logo) {
        try { if (alLogo(doc, set, o, ox)) R.layers++; else R.note = 'LOGO_SKIPPED'; }
        catch (e3) { R.note = 'LOGO_SKIPPED'; try { app.activeDocument = doc; } catch (e4) {} }
      }
    }
  }
  R.artboards = artboards;
  try { if (base && base.typename === 'ArtLayer' && base.kind === LayerKind.NORMAL) base.remove(); } catch (e5) {}
}

function alwaniBuild(P) {
  var oldR = app.preferences.rulerUnits, oldT = app.preferences.typeUnits, oldD = app.displayDialogs;
  try {
    app.preferences.rulerUnits = Units.PIXELS;
    app.preferences.typeUnits = TypeUnits.PIXELS;
    app.displayDialogs = DialogModes.NO;
    var n = P.pages.length;
    if (!n) throw new Error('NO_PAGES');
    var total = n * P.w + (n - 1) * P.gap;
    var doc = app.documents.add(new UnitValue(total, 'px'), new UnitValue(P.h, 'px'), 72, P.name, NewDocumentMode.RGB, DocumentFill.TRANSPARENT);
    var R = { layers: 0, pages: n, note: '' };
    $.global.alwaniP = P; $.global.alwaniDoc = doc; $.global.alwaniR = R;
    doc.suspendHistory('Alwani', 'alwaniDraw()');
    if (P.swatches && P.swatches.length) {
      for (var i = 0; i < P.swatches.length; i++) { try { alAddSwatch(P.swatches[i].name, P.swatches[i].hex); } catch (e1) { R.note = R.note || 'SWATCH_SKIPPED'; } }
    }
    if (P.ppi && P.ppi !== 72) { try { doc.resizeImage(undefined, undefined, P.ppi, ResampleMethod.NONE); } catch (e2) {} }
    try { app.runMenuItem(alST('fitOnScreen')); } catch (e3) {}
    $.global.alwaniP = null; $.global.alwaniDoc = null; $.global.alwaniR = null;
    app.preferences.rulerUnits = oldR; app.preferences.typeUnits = oldT; app.displayDialogs = oldD;
    return alJSON(R);
  } catch (e) {
    app.preferences.rulerUnits = oldR; app.preferences.typeUnits = oldT; app.displayDialogs = oldD;
    return alErr(e);
  }
}
