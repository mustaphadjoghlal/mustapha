@echo off
rem Alwani - Photoshop panel installer (per-user, no admin rights needed)
setlocal
set "SRC=%~dp0com.mustapha.alwani"
set "EXT=%APPDATA%\Adobe\CEP\extensions"
set "DEST=%EXT%\com.mustapha.alwani"
echo Installing Alwani...
if not exist "%SRC%\CSXS\manifest.xml" goto fail
if exist "%DEST%" rmdir /s /q "%DEST%"
if not exist "%EXT%" mkdir "%EXT%"
xcopy "%SRC%" "%DEST%\" /E /I /Y /Q >nul
if errorlevel 1 goto fail
if not exist "%DEST%\CSXS\manifest.xml" goto fail
rem allow unsigned panels for the current user only
for %%v in (9 10 11 12 13) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
echo.
echo Alwani installed. Restart Photoshop, then open: Window ^> Extensions (Legacy) ^> Alwani
pause
exit /b 0
:fail
echo.
echo Installation failed. Extract the whole zip first, then run this file again.
pause
exit /b 1
