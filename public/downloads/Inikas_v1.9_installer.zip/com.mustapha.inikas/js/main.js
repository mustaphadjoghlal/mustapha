(function () {
  'use strict';

  var E = window.InikasEngine;
  var LOW = 480;      // every decision about the ground is taken on a copy of this size (preview AND apply)
  var FULL = 5000;    // largest size the reflection itself is built at

  var PRESETS = {
    gloss: { opacity: 45, length: 60, curve: 40, gap: 0, squash: 100, skew: 0, blur: 0.4, blurType: 'gauss', ripple: 0 },
    glass: { opacity: 30, length: 45, curve: 35, gap: 0, squash: 100, skew: 0, blur: 0, blurType: 'gauss', ripple: 0 },
    matte: { opacity: 25, length: 40, curve: 30, gap: 0, squash: 85, skew: 0, blur: 2.5, blurType: 'motion', ripple: 0 },
    water: { opacity: 55, length: 85, curve: 55, gap: 1, squash: 90, skew: 0, blur: 0.8, blurType: 'motion', ripple: 120 }
  };
  var DEFAULTS = { shape: 'auto', curvFix: 100, tiltFix: 0 };
  var KEYS = ['shape', 'curvFix', 'tiltFix', 'opacity', 'length', 'curve', 'gap', 'squash', 'skew', 'blur', 'blurType', 'ripple'];
  var UNITS = { curvFix: '%', tiltFix: '°', opacity: '%', length: '%', curve: '', gap: '%', squash: '%', skew: '°', blur: '%', ripple: '' };
  var STORE = 'inikas.settings.v1';

  var $ = function (id) { return document.getElementById(id); };
  var canvas = $('preview'), ctx = canvas.getContext('2d');
  var src = null;     // { canvas, px, w, h, shape, base } — the small copy shown in the preview

  // ---------- Node (reading / writing files) ----------
  var nreq = null;
  try {
    if (window.cep_node && window.cep_node.require) nreq = window.cep_node.require;
    else if (typeof require === 'function') nreq = require;
  } catch (e) {}
  var fs = null, os = null, NodeBuffer = null;
  try { fs = nreq && nreq('fs'); os = nreq && nreq('os'); } catch (e) { fs = null; }
  try { NodeBuffer = typeof Buffer !== 'undefined' ? Buffer : (window.cep_node && window.cep_node.Buffer) || null; } catch (e) {}
  if (!NodeBuffer) fs = null;

  // ---------- host bridge ----------
  function evalHost(script, cb) {
    if (window.__adobe_cep__) window.__adobe_cep__.evalScript(script, cb || function () {});
    else if (cb) cb('ERR:NOHOST');
  }
  var ERRORS = {
    NODOC: 'لا يوجد مستند مفتوح.',
    BG: 'طبقة الخلفية مقفلة؛ حوّلها لطبقة عادية أو اختر طبقة أخرى.',
    ISREF: 'المحدد هو طبقة انعكاس؛ اختر العنصر الأصلي.',
    EMPTY: 'الطبقة المحددة فارغة.',
    NONE: 'لا يوجد انعكاس لهذه الطبقة.',
    NOHOST: 'افتح اللوحة من داخل الفوتوشوب.',
    READ: 'تعذر قراءة صورة الطبقة.',
    NOREF: 'لم ينتج انعكاس ظاهر بهذه الإعدادات (زد الشفافية أو طول التلاشي).'
  };
  function status(msg, ok) { var s = $('status'); s.textContent = msg; s.className = ok ? 'ok' : 'err'; }
  function errText(r) { var k = String(r).replace(/^ERR:/, ''); return ERRORS[k] || ('خطأ: ' + k); }

  // ---------- settings ----------
  function read() {
    var p = {};
    KEYS.forEach(function (k) { var el = $(k); p[k] = el.tagName === 'SELECT' ? el.value : parseFloat(el.value); });
    return p;
  }
  function write(p) { KEYS.forEach(function (k) { if (p[k] !== undefined) $(k).value = p[k]; }); refreshOutputs(); }
  function refreshOutputs() {
    KEYS.forEach(function (k) {
      var el = $(k), out = el.parentNode.querySelector('output');
      if (out) out.textContent = el.value + UNITS[k];
    });
  }
  function save() { try { localStorage.setItem(STORE, JSON.stringify(read())); } catch (e) {} }
  function load() { try { return JSON.parse(localStorage.getItem(STORE)); } catch (e) { return null; } }

  // ---------- image helpers ----------
  function toCanvas(img) {
    var c = document.createElement('canvas');
    c.width = img.naturalWidth || img.width; c.height = img.naturalHeight || img.height;
    c.getContext('2d').drawImage(img, 0, 0);
    return c;
  }
  function pixelsToCanvas(px, w, h, pad) {
    pad = pad || 0;
    var c = document.createElement('canvas'); c.width = w + pad * 2; c.height = h + pad * 2;
    var g = c.getContext('2d'), id = g.createImageData(w, h);
    id.data.set(px);
    g.putImageData(id, pad, pad);
    return c;
  }
  function loadImagePath(path, cb, fail) {
    var im = new Image();
    im.onload = function () { cb(im); };
    im.onerror = fail;
    if (fs) {
      try { im.src = 'data:image/png;base64,' + fs.readFileSync(path).toString('base64'); return; } catch (e) {}
    }
    im.src = encodeURI('file:///' + path.replace(/\\/g, '/').replace(/^\/+/, '')) + '?t=' + Date.now();
  }

  // Asks Photoshop for the selected layer as a trimmed PNG no larger than maxSize.
  // cb(err, { canvas, px, w, h, L, T, scale, res })   L/T: where the picture sits in the document
  function exportLayer(maxSize, cb) {
    evalHost('inikas_export(' + maxSize + ')', function (r) {
      if (!r || String(r).indexOf('OK:') !== 0) { cb(r || 'ERR:UNKNOWN'); return; }
      var parts = String(r).slice(3).split('|');
      var e = { path: parts[0], L: parseFloat(parts[1]), T: parseFloat(parts[2]), scale: parseFloat(parts[3]) || 1, res: parseFloat(parts[4]) || 72 };
      loadImagePath(e.path, function (im) {
        try {
          e.canvas = toCanvas(im); e.w = e.canvas.width; e.h = e.canvas.height;
          e.px = e.canvas.getContext('2d').getImageData(0, 0, e.w, e.h).data;
          cb(null, e);
        } catch (x) { cb('ERR:' + x.message); }
      }, function () { cb('ERR:READ'); });
    });
  }

  // ---------- preview-only approximations of the Photoshop filters ----------
  function postFX(srcC, p, hRef) {
    var w = srcC.width, h = srcC.height, b = srcC;
    if (p.ripple > 0) {
      b = document.createElement('canvas'); b.width = w; b.height = h;
      var bc = b.getContext('2d');
      var amp = p.ripple / 100 * hRef * 0.012, period = Math.max(3, hRef * 0.03);
      for (var y = 0; y < h; y += 2) {
        var dx = amp * Math.sin(y / period) + amp * 0.5 * Math.sin(y / (period * 0.37));
        bc.drawImage(srcC, 0, y, w, 2, dx, y, w, 2);
      }
    }
    var blurPx = p.blur / 100 * hRef;
    if (blurPx < 0.2) return b;
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    var cc = c.getContext('2d');
    if (p.blurType === 'motion') {
      var dist = blurPx * 2, steps = Math.max(4, Math.min(24, Math.round(dist)));
      cc.globalAlpha = 1.6 / steps;
      for (var i = 0; i < steps; i++) cc.drawImage(b, 0, -dist / 2 + dist * i / (steps - 1));
      cc.globalAlpha = 1;
    } else {
      cc.filter = 'blur(' + blurPx.toFixed(2) + 'px)';
      cc.drawImage(b, 0, 0);
      cc.filter = 'none';
    }
    return c;
  }

  // ---------- preview ----------
  function sampleImage() {
    // Neutral cylinder (paint-can-like, seen slightly from above) shown until a layer is loaded
    var c = document.createElement('canvas'); c.width = 200; c.height = 230;
    var g = c.getContext('2d');
    var grd = g.createLinearGradient(0, 0, 200, 0);
    grd.addColorStop(0, '#1b5fb5'); grd.addColorStop(0.4, '#76bdf7'); grd.addColorStop(1, '#0d3a75');
    g.fillStyle = grd;
    g.beginPath(); g.moveTo(0, 22); g.lineTo(0, 205);
    g.ellipse(100, 205, 100, 24, 0, Math.PI, 0, true);
    g.lineTo(200, 22); g.ellipse(100, 22, 100, 22, 0, 0, Math.PI, true); g.fill();
    g.fillStyle = '#c9d6e3'; g.beginPath(); g.ellipse(100, 22, 100, 22, 0, 0, Math.PI * 2); g.fill();
    g.strokeStyle = '#8a9aab'; g.lineWidth = 3; g.beginPath(); g.ellipse(100, 22, 90, 18, 0, 0, Math.PI * 2); g.stroke();
    g.fillStyle = 'rgba(255,255,255,.92)';
    g.beginPath(); g.moveTo(0, 95); g.ellipse(100, 95, 100, 23, 0, Math.PI, 0, true);
    g.lineTo(200, 150); g.ellipse(100, 150, 100, 23, 0, 0, Math.PI, false); g.closePath(); g.fill();
    g.fillStyle = '#e8562a';
    g.beginPath(); g.moveTo(0, 115); g.ellipse(100, 115, 100, 23, 0, Math.PI, 0, true);
    g.lineTo(200, 128); g.ellipse(100, 128, 100, 23, 0, 0, Math.PI, false); g.closePath(); g.fill();
    return c;
  }

  function setSource(c, px) {
    src = { canvas: c, w: c.width, h: c.height, px: px || c.getContext('2d').getImageData(0, 0, c.width, c.height).data, shape: null, base: null };
  }
  function analysed(shape) {
    if (src.shape !== shape) { src.base = E.analyze(src.px, src.w, src.h, shape); src.shape = shape; }
    return src.base;
  }

  function drawBackground(W, H, floorY) {
    var mode = $('bg').value;
    if (mode === 'checker') {
      var s = 16;
      for (var y = 0; y < H; y += s) for (var x = 0; x < W; x += s) {
        ctx.fillStyle = ((x / s + y / s) % 2) ? '#cfcfcf' : '#f2f2f2'; ctx.fillRect(x, y, s, s);
      }
      return;
    }
    var dark = mode === 'dark';
    var top = ctx.createLinearGradient(0, 0, 0, floorY);
    top.addColorStop(0, dark ? '#2a2f38' : '#fafafa'); top.addColorStop(1, dark ? '#1a1d23' : '#e9e9e9');
    ctx.fillStyle = top; ctx.fillRect(0, 0, W, floorY);
    var fl = ctx.createLinearGradient(0, floorY, 0, H);
    fl.addColorStop(0, dark ? '#121418' : '#dcdcdc'); fl.addColorStop(1, dark ? '#0b0c0f' : '#cfcfcf');
    ctx.fillStyle = fl; ctx.fillRect(0, floorY, W, H - floorY);
  }

  function updateShapeUI(p, base) {
    $('curvRow').classList.toggle('hidden', base.multi || !base.cyl);
    var parts = [], bridged = 0, i;
    for (i = 0; i < base.bridge.length; i++) bridged += base.bridge[i];
    if (base.multi) parts.push('عدة منتجات — كل منتج ينعكس من قاعدته');
    else {
      parts.push(base.cyl ? ('قاعدة أسطوانية (انحناء ' + Math.round(base.ratio * 100) + '%)') : 'قاعدة مستقيمة');
      var tilt = base.tiltDeg + p.tiltFix;
      parts.push(Math.abs(tilt) >= 0.5 ? ('خط الأرض مائل ' + tilt.toFixed(1) + '°') : 'خط الأرض أفقي');
      if (bridged) parts.push('الأرض موصولة تحت الأجزاء المرفوعة');
    }
    $('shapeInfo').textContent = parts.join(' · ');
  }

  function render() {
    var p = read(), base = analysed(p.shape);
    updateShapeUI(p, base);
    var ct = E.contact(base, p), FL = E.fadeLen(base, ct.C, p);
    var r = E.warp(src.px, src.w, src.h, ct.C, FL, p);
    var pad = Math.ceil(p.blur / 100 * src.h * 3 + p.ripple / 100 * src.h * 0.03 + 3);
    var fx = postFX(pixelsToCanvas(r.data, r.w, r.h, pad), p, src.h);

    var W = canvas.width, H = canvas.height, iw = src.w, ih = src.h;
    var minX = Math.min(0, r.left), maxX = Math.max(iw, r.left + r.w), maxY = Math.max(ih, r.top + r.h * 0.8);
    var k = Math.min((W * 0.88) / (maxX - minX), (H * 0.94) / maxY);
    var ox = (W - (maxX - minX) * k) / 2 - minX * k, oy = (H - maxY * k) / 2;
    var hi = Infinity, x;
    for (x = 0; x < iw; x++) if (base.cb[x] >= 0 && ct.C[x] < hi) hi = ct.C[x];
    var floorY = oy + (hi === Infinity ? ih * 0.9 : hi - ih * 0.02) * k;

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, W, H);
    drawBackground(W, H, floorY);
    ctx.globalAlpha = p.opacity / 100;
    ctx.drawImage(fx, ox + (r.left - pad) * k, oy + (r.top - pad) * k, fx.width * k, fx.height * k);
    ctx.globalAlpha = 1;
    ctx.drawImage(src.canvas, ox, oy, iw * k, ih * k);
  }

  // ---------- actions ----------
  function loadLayer() {
    exportLayer(LOW, function (err, e) {
      if (err) { status(errText(err), false); return; }
      setSource(e.canvas, e.px); render();
      evalHost('app.activeDocument.activeLayer.name', function (n) { $('layerName').textContent = n || '—'; });
      status('تم تحميل الطبقة في المعاينة.', true);
    });
  }

  // Builds the reflection picture and hands it to Photoshop with the exact rectangle it must occupy.
  function applySmart(p, done) {
    if (!fs || !os) { applyFlat(p, done); return; }
    status('جارٍ تحليل الطبقة…', true);
    exportLayer(LOW, function (err, lo) {
      if (err) { done(err); return; }
      var base, ct, FL;
      try {
        // same small copy and same code as the preview: what the preview shows is what gets built
        setSource(lo.canvas, lo.px);
        base = analysed(p.shape); ct = E.contact(base, p); FL = E.fadeLen(base, ct.C, p);
        render();
      } catch (x) { done('ERR:' + x.message); return; }

      function build(hi) {
        var out = null;
        try {
          var up = (hi.w === lo.w && hi.h === lo.h) ? { C: ct.C, FL: FL }
                 : E.upsample({ w: lo.w, h: lo.h, C: ct.C, FL: FL, snap: ct.snap }, hi.px, hi.w, hi.h);
          var cr = E.crop(E.warp(hi.px, hi.w, hi.h, up.C, up.FL, p), 8);
          if (!cr) { done('ERR:NOREF'); return; }
          var png = NodeBuffer.from(pixelsToCanvas(cr.data, cr.w, cr.h).toDataURL('image/png').split(',')[1], 'base64');
          png = E.pngSetPpi(png, hi.res * hi.scale);          // same resolution as the document: placed at 100%
          out = os.tmpdir().replace(/\\/g, '/') + '/inikas_reflection_' + Date.now() + '.png';
          fs.writeFileSync(out, NodeBuffer.from(png));
          var inv = 1 / hi.scale;
          var args = {
            path: out,
            x: hi.L + cr.left * inv, y: hi.T + cr.top * inv, w: cr.w * inv, h: cr.h * inv,
            blurType: p.blurType, blurPx: p.blur / 100 * hi.h * inv, ripple: p.ripple, opacity: p.opacity
          };
          status('جارٍ وضع الانعكاس…', true);
          evalHost('inikas_place(' + JSON.stringify(args) + ')', function (rr) {
            try { fs.unlinkSync(out); } catch (x) {}
            done(rr);
          });
        } catch (x) {
          try { if (out) fs.unlinkSync(out); } catch (y) {}
          done('ERR:' + x.message);
        }
      }
      if (lo.scale >= 1) build(lo);      // small layer: the copy is the layer itself
      else exportLayer(FULL, function (err2, hi) { if (err2) done(err2); else build(hi); });
    });
  }
  // Fallback when the panel cannot read/write files: Photoshop's own transforms (level ground only)
  function applyFlat(p, done) { evalHost('inikas_apply(' + JSON.stringify(p) + ')', done); }

  // "OK|dl,dt,dw,dh|how" → how far the placed layer ended up from where it had to be (document pixels)
  function placement(r) {
    var parts = String(r).split('|'), worst = 0;
    (parts[1] || '').split(',').forEach(function (v) { v = Math.abs(parseFloat(v)); if (v > worst) worst = v; });
    return { has: parts.length > 1 && parts[1] !== '', worst: worst, text: parts[1] || '', how: parts[2] || '', stale: parseInt(parts[3], 10) || 0 };
  }
  function isOK(r) { return String(r).indexOf('OK') === 0; }

  function apply() {
    var p = read();
    var btn = $('btnApply'); btn.disabled = true; status('جارٍ التطبيق…', true);
    evalHost('inikas_selectedIDs()', function (r) {
      if (!r || String(r).indexOf('OK:') !== 0) { btn.disabled = false; status(errText(r), false); return; }
      var ids = String(r).slice(3).split(','), i = 0, okCount = 0, lastErr = '', worst = 0, worstText = '', checked = false, stale = 0;
      function next() {
        if (i >= ids.length) {
          if (ids.length > 1) evalHost('inikas_reselect("' + ids.join(',') + '")');
          btn.disabled = false;
          if (okCount === ids.length) {
            if (checked && worst > 1.5) status('تم الإنشاء، لكن فحص الموضع وجد انحرافًا: ' + worstText + ' بكسل — أرسل لي هذه الأرقام.', false);
            else if (stale) status('تم إنشاء الانعكاس ✓ — تنبيه: تحته طبقة انعكاس قديمة تخص طبقة أخرى (' + stale + ')؛ احذفها أو أخفِها لترى النتيجة الصحيحة.', false);
            else status((ids.length > 1 ? ('تم إنشاء ' + okCount + ' انعكاسات ✓') : 'تم إنشاء الانعكاس ✓') + (checked ? ' — الموضع مطابق للمعاينة' : '') + ' (تراجع: Ctrl+Z)', true);
          } else if (okCount) status('تم ' + okCount + ' من ' + ids.length + ' — ' + errText(lastErr), false);
          else status(errText(lastErr), false);
          return;
        }
        var id = ids[i++];
        if (ids.length > 1) status('جارٍ معالجة ' + i + ' من ' + ids.length + '…', true);
        evalHost('inikas_selectID(' + parseInt(id, 10) + ')', function (sr) {
          if (!sr || String(sr).indexOf('OK:') !== 0) { lastErr = sr; next(); return; }
          applySmart(p, function (res) {
            if (isOK(res)) {
              okCount++;
              var pl = placement(res);
              if (pl.has) { checked = true; stale += pl.stale; if (pl.worst > worst) { worst = pl.worst; worstText = pl.text; } }
            } else lastErr = res;
            next();
          });
        });
      }
      next();
    });
  }

  function remove() {
    evalHost('inikas_remove()', function (r) {
      if (r === 'OK') status('تم حذف الانعكاس.', true); else status(errText(r), false);
    });
  }

  // ---------- wiring ----------
  function clearPresetMarks() {
    Array.prototype.forEach.call(document.querySelectorAll('.presets button'), function (b) { b.classList.remove('active'); });
  }
  KEYS.forEach(function (k) {
    $(k).addEventListener('input', function () { refreshOutputs(); render(); save(); if (k !== 'shape' && k !== 'curvFix' && k !== 'tiltFix') clearPresetMarks(); });
    $(k).addEventListener('change', function () { refreshOutputs(); render(); save(); });
  });
  Array.prototype.forEach.call(document.querySelectorAll('.presets button'), function (b) {
    b.addEventListener('click', function () {
      write(PRESETS[b.getAttribute('data-preset')]); render(); save();
      Array.prototype.forEach.call(document.querySelectorAll('.presets button'), function (x) { x.classList.toggle('active', x === b); });
    });
  });
  $('bg').addEventListener('change', render);
  $('btnLoad').addEventListener('click', loadLayer);
  $('btnApply').addEventListener('click', apply);
  $('btnRemove').addEventListener('click', remove);

  var saved = load() || {};
  if (saved.shape === 'cyl' || saved.shape === 'flat') saved.shape = 'auto';
  write(Object.assign({}, PRESETS.gloss, DEFAULTS, saved));
  setSource(sampleImage());
  render();
  if (window.__adobe_cep__) loadLayer();
})();
