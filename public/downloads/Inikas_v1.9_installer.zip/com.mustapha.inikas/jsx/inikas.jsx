// Inikas - surface reflection for Photoshop
// ExtendScript (ES3). This file is pure ASCII on purpose: every non-ASCII character is written as \uXXXX.

function cTID(s) { return charIDToTypeID(s); }
function sTID(s) { return stringIDToTypeID(s); }

var INIKAS_WORD = "\u0627\u0646\u0639\u0643\u0627\u0633";          // the Arabic word for "reflection"
var INIKAS_PREFIX = INIKAS_WORD + " \u2022 ";                       // reflection layers are named: word + bullet + source name
var INIKAS_MARK_OLD = "\u00E2\u20AC\u00A2 ";                        // the bullet as versions before 1.9 may have written it
var INIKAS_P = null;
var INIKAS_RESULT = "";
var INIKAS_HOW = "b";

// Name of the layer a reflection belongs to, or null when the layer is not one of our reflections.
function inikas_refSource(name) {
    if (name.indexOf(INIKAS_PREFIX) == 0) return name.substring(INIKAS_PREFIX.length);
    var k = name.indexOf(INIKAS_MARK_OLD);
    if (k == 13) {
        for (var i = 0; i < 12; i++) if (name.charCodeAt(i) < 128) return null;
        return name.substring(k + INIKAS_MARK_OLD.length);
    }
    return null;
}

// Removes every earlier reflection of this layer (same folder). Returns how many were removed.
function inikas_removeOld(src) {
    var sibs = src.parent.layers, names = [], i, n = 0, srcName = src.name;
    for (i = 0; i < sibs.length; i++) if (inikas_refSource(sibs[i].name) == srcName) names.push(sibs[i].name);
    for (i = 0; i < names.length; i++) {
        try { src.parent.layers.getByName(names[i]).remove(); n++; } catch (e) {}
    }
    return n;
}

function inikas_px(v) { return v.as ? v.as("px") : Number(v); }

function inikas_boundsOf(layer) {
    var b = layer.bounds;
    return { l: inikas_px(b[0]), t: inikas_px(b[1]), r: inikas_px(b[2]), b: inikas_px(b[3]) };
}

function inikas_skew(angle) {
    var d = new ActionDescriptor();
    var r = new ActionReference();
    r.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
    d.putReference(cTID('null'), r);
    d.putEnumerated(cTID('FTcs'), cTID('QCSt'), cTID('Qcs4')); // top side fixed
    var o = new ActionDescriptor();
    o.putUnitDouble(cTID('Hrzn'), cTID('#Pxl'), 0);
    o.putUnitDouble(cTID('Vrtc'), cTID('#Pxl'), 0);
    d.putObject(cTID('Ofst'), cTID('Ofst'), o);
    var s = new ActionDescriptor();
    s.putUnitDouble(cTID('Hrzn'), cTID('#Ang'), angle);
    s.putUnitDouble(cTID('Vrtc'), cTID('#Ang'), 0);
    d.putObject(cTID('Skew'), cTID('Pnt '), s);
    d.putEnumerated(cTID('Intr'), cTID('Intp'), cTID('Bcbc'));
    executeAction(cTID('Trnf'), d, DialogModes.NO);
}

// Positive angle = bottom of the reflection leans to the right (matches the panel preview).
function inikas_applySkew(layer, angle) {
    if (!angle) return;
    var before = inikas_boundsOf(layer);
    inikas_skew(angle);
    var after = inikas_boundsOf(layer);
    var wentRight = (after.r - before.r) > (before.l - after.l);
    if ((angle > 0) != wentRight) {
        // Wrong direction: compose a second shear so total tan = -tan(angle)
        var k = Math.tan(angle * Math.PI / 180);
        var fix = Math.atan(-2 * k) * 180 / Math.PI;
        inikas_skew(fix);
    }
}

function inikas_gradientStop(list, v, loc, mid) {
    var s = new ActionDescriptor();
    var c = new ActionDescriptor();
    c.putDouble(cTID('Rd  '), v);
    c.putDouble(cTID('Grn '), v);
    c.putDouble(cTID('Bl  '), v);
    s.putObject(cTID('Clr '), cTID('RGBC'), c);
    s.putEnumerated(cTID('Type'), cTID('Clry'), cTID('UsrS'));
    s.putInteger(cTID('Lctn'), loc);
    s.putInteger(cTID('Mdpn'), mid);
    list.putObject(cTID('Clrt'), s);
}

function inikas_maskGradient(x, y0, y1, mid) {
    // Add a reveal-all mask (it becomes the active channel)
    var d = new ActionDescriptor();
    d.putClass(cTID('Nw  '), cTID('Chnl'));
    var r = new ActionReference();
    r.putEnumerated(cTID('Chnl'), cTID('Chnl'), cTID('Msk '));
    d.putReference(cTID('At  '), r);
    d.putEnumerated(cTID('Usng'), cTID('UsrM'), cTID('RvlA'));
    executeAction(cTID('Mk  '), d, DialogModes.NO);

    // White -> black linear gradient on the mask
    var g = new ActionDescriptor();
    var f = new ActionDescriptor();
    f.putUnitDouble(cTID('Hrzn'), cTID('#Pxl'), x);
    f.putUnitDouble(cTID('Vrtc'), cTID('#Pxl'), y0);
    g.putObject(cTID('From'), cTID('Pnt '), f);
    var t = new ActionDescriptor();
    t.putUnitDouble(cTID('Hrzn'), cTID('#Pxl'), x);
    t.putUnitDouble(cTID('Vrtc'), cTID('#Pxl'), y1);
    g.putObject(cTID('T   '), cTID('Pnt '), t);
    g.putEnumerated(cTID('Type'), cTID('GrdT'), cTID('Lnr '));
    g.putBoolean(cTID('Dthr'), true);
    g.putBoolean(cTID('UsMs'), true);

    var gr = new ActionDescriptor();
    gr.putString(cTID('Nm  '), 'Inikas');
    gr.putEnumerated(cTID('GrdF'), cTID('GrdF'), cTID('CstS'));
    gr.putDouble(cTID('Intr'), 4096);
    var cl = new ActionList();
    inikas_gradientStop(cl, 255, 0, mid);
    inikas_gradientStop(cl, 0, 4096, 50);
    gr.putList(cTID('Clrs'), cl);
    var tl = new ActionList();
    for (var i = 0; i < 2; i++) {
        var ts = new ActionDescriptor();
        ts.putUnitDouble(cTID('Opct'), cTID('#Prc'), 100);
        ts.putInteger(cTID('Lctn'), i * 4096);
        ts.putInteger(cTID('Mdpn'), 50);
        tl.putObject(cTID('TrnS'), ts);
    }
    gr.putList(cTID('Trns'), tl);
    g.putObject(cTID('Grad'), cTID('Grdn'), gr);
    executeAction(cTID('Grdn'), g, DialogModes.NO);
}

function inikas_build() {
    var p = INIKAS_P;
    var doc = app.activeDocument;
    var src = doc.activeLayer;

    inikas_removeOld(src);
    doc.activeLayer = src;

    var sb = inikas_boundsOf(src);
    var w = sb.r - sb.l, h = sb.b - sb.t;
    if (w < 1 || h < 1) { INIKAS_RESULT = "ERR:EMPTY"; return; }

    var ref = src.duplicate(src, ElementPlacement.PLACEAFTER); // directly below
    doc.activeLayer = ref;
    if (ref.typename == "LayerSet" || ref.kind != LayerKind.SMARTOBJECT) {
        executeAction(sTID('newPlacedLayer'), undefined, DialogModes.NO);
        ref = doc.activeLayer;
    }
    ref.name = INIKAS_PREFIX + src.name;

    // Flip + squash, anchored on the object's bottom edge
    ref.resize(100, -Math.max(1, p.squash), AnchorPosition.BOTTOMCENTER);

    // Gap (relative to object height)
    var gap = p.gap / 100 * h;
    if (gap) ref.translate(0, gap);

    inikas_applySkew(ref, p.skew);

    // Filters (become Smart Filters)
    inikas_filters(p.blurType, p.blur / 100 * h, p.ripple);

    // Fade mask
    var refH = h * p.squash / 100;
    var y0 = sb.b + gap;
    var y1 = y0 + Math.max(1, p.length / 100 * refH);
    var mid = Math.max(13, Math.min(87, Math.round(p.curve)));
    inikas_maskGradient(sb.l + w / 2, y0, y1, mid);

    // Hide anything that bleeds above the contact line (blur/ripple)
    var W = inikas_px(doc.width);
    if (y0 > 1) {
        doc.selection.select([[0, 0], [W, 0], [W, y0], [0, y0]]);
        var black = new SolidColor();
        black.rgb.red = 0; black.rgb.green = 0; black.rgb.blue = 0;
        doc.selection.fill(black);
        doc.selection.deselect();
    }

    ref.opacity = Math.max(0, Math.min(100, p.opacity));
    doc.activeLayer = src;
    INIKAS_RESULT = "OK";
}

function inikas_apply(p) {
    if (!app.documents.length) return "ERR:NODOC";
    var doc = app.activeDocument;
    var src = doc.activeLayer;
    if (src.isBackgroundLayer) return "ERR:BG";
    if (inikas_refSource(src.name) !== null) return "ERR:ISREF";
    var units = app.preferences.rulerUnits;
    app.preferences.rulerUnits = Units.PIXELS;
    INIKAS_P = p;
    INIKAS_RESULT = "ERR:UNKNOWN";
    try {
        doc.suspendHistory("\u0627\u0646\u0639\u0643\u0627\u0633", "inikas_build()");
    } catch (e) {
        INIKAS_RESULT = "ERR:" + e.message;
    }
    app.preferences.rulerUnits = units;
    return INIKAS_RESULT;
}

function inikas_remove() {
    if (!app.documents.length) return "ERR:NODOC";
    var doc = app.activeDocument;
    var src = doc.activeLayer;
    if (inikas_refSource(src.name) !== null) { src.remove(); return "OK"; }
    if (!inikas_removeOld(src)) return "ERR:NONE";
    doc.activeLayer = src;
    return "OK";
}

// Export the active layer (trimmed) as PNG. Returns "OK:path|left|top|scale|documentResolution"
function inikas_export(maxSize) {
    if (!app.documents.length) return "ERR:NODOC";
    var doc = app.activeDocument;
    var l = doc.activeLayer;
    if (l.isBackgroundLayer) return "ERR:BG";
    if (inikas_refSource(l.name) !== null) return "ERR:ISREF";
    var units = app.preferences.rulerUnits;
    app.preferences.rulerUnits = Units.PIXELS;
    var nd = null;
    try {
        var b = inikas_boundsOf(l);
        if (b.r - b.l < 1 || b.b - b.t < 1) { app.preferences.rulerUnits = units; return "ERR:EMPTY"; }
        var L = Math.max(0, b.l), T = Math.max(0, b.t), res = doc.resolution;
        nd = app.documents.add(doc.width, doc.height, 72, "inikas_tmp", NewDocumentMode.RGB, DocumentFill.TRANSPARENT);
        app.activeDocument = doc;
        l.duplicate(nd, ElementPlacement.PLACEATBEGINNING);
        app.activeDocument = nd;
        try { nd.layers[0].opacity = 100; } catch (eo) {}      // a faded layer still has a solid outline
        try { nd.layers[0].fillOpacity = 100; } catch (ef) {}
        nd.trim(TrimType.TRANSPARENT, true, true, true, true);
        var w = inikas_px(nd.width), h = inikas_px(nd.height);
        var m = Math.max(w, h), scale = 1;
        if (m > maxSize) {
            var nw = Math.max(1, Math.round(w * maxSize / m)), nh = Math.max(1, Math.round(h * maxSize / m));
            nd.resizeImage(UnitValue(nw, "px"), UnitValue(nh, "px"), 72, ResampleMethod.BICUBIC);
            scale = inikas_px(nd.width) / w;                    // measured, not assumed
        }
        var f = new File(Folder.temp + "/inikas_src_" + maxSize + ".png");
        nd.saveAs(f, new PNGSaveOptions(), true, Extension.LOWERCASE);
        nd.close(SaveOptions.DONOTSAVECHANGES);
        nd = null;
        app.activeDocument = doc;
        app.preferences.rulerUnits = units;
        return "OK:" + f.fsName + "|" + L + "|" + T + "|" + scale + "|" + res;
    } catch (e) {
        try { if (nd) nd.close(SaveOptions.DONOTSAVECHANGES); app.activeDocument = doc; } catch (e2) {}
        app.preferences.rulerUnits = units;
        return "ERR:" + e.message;
    }
}
function inikas_preview() { return inikas_export(480); }

function inikas_filters(blurType, blurPx, ripple) {
    if (blurPx >= 0.3) {
        var d = new ActionDescriptor();
        if (blurType == "motion") {
            d.putInteger(cTID('Angl'), 90);
            d.putUnitDouble(cTID('Dstn'), cTID('#Pxl'), Math.min(2000, Math.max(1, Math.round(blurPx * 2))));
            executeAction(cTID('MtnB'), d, DialogModes.NO);
        } else {
            d.putUnitDouble(cTID('Rds '), cTID('#Pxl'), Math.min(1000, blurPx));
            executeAction(cTID('GsnB'), d, DialogModes.NO);
        }
    }
    if (ripple > 0) {
        var rd = new ActionDescriptor();
        rd.putInteger(cTID('Amnt'), Math.min(999, Math.round(ripple)));
        rd.putEnumerated(cTID('RplS'), cTID('RplS'), cTID('Mdm '));
        executeAction(cTID('Rple'), rd, DialogModes.NO);
    }
}

// Rectangle of the active smart object taken from its own transform: exact, and independent of how
// transparent its pixels are. null when this Photoshop version does not expose it.
function inikas_soRect() {
    try {
        var r = new ActionReference();
        r.putProperty(sTID('property'), sTID('smartObjectMore'));
        r.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
        var d = executeActionGet(r);
        if (!d.hasKey(sTID('smartObjectMore'))) return null;
        var so = d.getObjectValue(sTID('smartObjectMore'));
        if (!so.hasKey(sTID('transform'))) return null;
        var t = so.getList(sTID('transform'));
        if (t.count != 8) return null;
        var l = 1e12, tp = 1e12, rt = -1e12, bt = -1e12, i, x, y;
        for (i = 0; i < 8; i += 2) {
            x = t.getDouble(i); y = t.getDouble(i + 1);
            if (x < l) l = x;
            if (x > rt) rt = x;
            if (y < tp) tp = y;
            if (y > bt) bt = y;
        }
        return { l: l, t: tp, r: rt, b: bt };
    } catch (e) { return null; }
}

// Where the placed picture really is. The transform is preferred; the pixel bounds confirm it
// (or replace it when the two do not describe the same rectangle).
function inikas_measure(layer) {
    var b = inikas_boundsOf(layer), q = inikas_soRect();
    INIKAS_HOW = "b";
    if (q) {
        var bw = b.r - b.l, bh = b.b - b.t, qw = q.r - q.l, qh = q.b - q.t;
        if (bw > 0 && bh > 0 && qw / bw > 0.9 && qw / bw < 1.15 && qh / bh > 0.9 && qh / bh < 1.3 &&
            q.l < b.l + 2 && q.t < b.t + 2 && q.r > b.r - 2 && q.b > b.b - 2) { INIKAS_HOW = "q"; return q; }
    }
    return b;
}

// Brings the placed picture to exactly the rectangle p.x, p.y, p.w, p.h and re-measures until it is there.
function inikas_fit(ref, p) {
    var m = inikas_measure(ref), i, gain = 1;
    for (i = 0; i < 4; i++) {
        var mw = m.r - m.l, mh = m.b - m.t;
        if (mw < 1 || mh < 1) break;
        var sx = p.w / mw, sy = p.h / mh;
        if (Math.abs(sx - sy) < 0.01) sy = sx;      // a placed picture keeps its proportions: trust the width
        // pixel bounds are whole numbers: a difference of one pixel is rounding, not a different size
        var tolS = INIKAS_HOW == "q" ? 0.0004 : Math.max(0.0004, 1.2 / Math.max(mw, mh));
        if (Math.abs(sx - 1) > tolS || Math.abs(sy - 1) > tolS) {
            ref.resize(sx * 100, sy * 100, AnchorPosition.TOPLEFT);
            m = inikas_measure(ref);
        }
        var dx = p.x - m.l, dy = p.y - m.t;
        if (Math.abs(dx) > 0.02 || Math.abs(dy) > 0.02) {
            var before = m;
            ref.translate(dx / gain, dy / gain);
            m = inikas_measure(ref);
            // if it moved by another amount than asked, learn the ratio for the next pass
            var asked = Math.abs(dx) >= Math.abs(dy) ? dx / gain : dy / gain;
            var got = Math.abs(dx) >= Math.abs(dy) ? m.l - before.l : m.t - before.t;
            if (Math.abs(asked) > 3 && got / asked > 0.05 && got / asked < 20) gain = got / asked;
        }
        if (Math.abs(m.l - p.x) < 0.6 && Math.abs(m.t - p.y) < 0.6 &&
            Math.abs((m.r - m.l) - p.w) < 1.2 && Math.abs((m.b - m.t) - p.h) < 1.2) break;
    }
    return m;
}

function inikas_r2(v) { return Math.round(v * 100) / 100; }

// Places the reflection picture built by the panel
function inikas_placeBuild() {
    var p = INIKAS_P;
    var doc = app.activeDocument;
    var src = doc.activeLayer;
    var srcName = src.name;
    inikas_removeOld(src);
    doc.activeLayer = src;

    var d = new ActionDescriptor();
    d.putPath(cTID('null'), new File(p.path));
    d.putEnumerated(cTID('FTcs'), cTID('QCSt'), cTID('Qcsa'));
    var o = new ActionDescriptor();
    o.putUnitDouble(cTID('Hrzn'), cTID('#Pxl'), 0);
    o.putUnitDouble(cTID('Vrtc'), cTID('#Pxl'), 0);
    d.putObject(cTID('Ofst'), cTID('Ofst'), o);
    executeAction(cTID('Plc '), d, DialogModes.NO);

    var ref = doc.activeLayer;
    var m = inikas_fit(ref, p);
    var dev = [inikas_r2(m.l - p.x), inikas_r2(m.t - p.y), inikas_r2((m.r - m.l) - p.w), inikas_r2((m.b - m.t) - p.h)];
    var how = INIKAS_HOW;

    ref.name = INIKAS_PREFIX + srcName;
    ref.move(src, ElementPlacement.PLACEAFTER);
    doc.activeLayer = ref;
    inikas_filters(p.blurType, p.blurPx, p.ripple);
    ref.opacity = Math.max(0, Math.min(100, p.opacity));

    // reflections of OTHER layers lying under the same spot (left over from earlier attempts)
    var stale = 0;
    try {
        var sibs = ref.parent.layers, i, rs, sb, ix, iy, a1, a2;
        for (i = 0; i < sibs.length; i++) {
            rs = inikas_refSource(sibs[i].name);
            if (rs === null || rs == srcName || !sibs[i].visible) continue;
            sb = inikas_boundsOf(sibs[i]);
            ix = Math.min(sb.r, m.r) - Math.max(sb.l, m.l);
            iy = Math.min(sb.b, m.b) - Math.max(sb.t, m.t);
            if (ix <= 0 || iy <= 0) continue;
            a1 = (sb.r - sb.l) * (sb.b - sb.t); a2 = (m.r - m.l) * (m.b - m.t);
            if (ix * iy > 0.4 * Math.min(a1, a2)) stale++;
        }
    } catch (e) {}

    doc.activeLayer = src;
    INIKAS_RESULT = "OK|" + dev.join(",") + "|" + how + "|" + stale;
}

function inikas_place(p) {
    if (!app.documents.length) return "ERR:NODOC";
    var doc = app.activeDocument;
    var units = app.preferences.rulerUnits;
    app.preferences.rulerUnits = Units.PIXELS;
    INIKAS_P = p;
    INIKAS_RESULT = "ERR:UNKNOWN";
    try {
        doc.suspendHistory("\u0627\u0646\u0639\u0643\u0627\u0633", "inikas_placeBuild()");
    } catch (e) {
        INIKAS_RESULT = "ERR:" + e.message;
    }
    app.preferences.rulerUnits = units;
    return INIKAS_RESULT;
}

// IDs of all selected layers, comma separated (falls back to the active layer)
function inikas_selectedIDs() {
    if (!app.documents.length) return "ERR:NODOC";
    var ids = [];
    try {
        var r = new ActionReference();
        r.putProperty(sTID('property'), sTID('targetLayersIDs'));
        r.putEnumerated(cTID('Dcmn'), cTID('Ordn'), cTID('Trgt'));
        var d = executeActionGet(r);
        if (d.hasKey(sTID('targetLayersIDs'))) {
            var l = d.getList(sTID('targetLayersIDs'));
            for (var i = 0; i < l.count; i++) ids.push(l.getReference(i).getIdentifier());
        }
    } catch (e) {}
    if (!ids.length) {
        try {
            var r2 = new ActionReference();
            r2.putProperty(sTID('property'), sTID('layerID'));
            r2.putEnumerated(cTID('Lyr '), cTID('Ordn'), cTID('Trgt'));
            ids.push(executeActionGet(r2).getInteger(sTID('layerID')));
        } catch (e2) { return "ERR:NOLAYER"; }
    }
    return "OK:" + ids.join(",");
}

function inikas_selectID(id) {
    try {
        var d = new ActionDescriptor();
        var r = new ActionReference();
        r.putIdentifier(cTID('Lyr '), id);
        d.putReference(cTID('null'), r);
        d.putBoolean(cTID('MkVs'), false);
        executeAction(cTID('slct'), d, DialogModes.NO);
        return "OK:" + app.activeDocument.activeLayer.name;
    } catch (e) { return "ERR:" + e.message; }
}

function inikas_reselect(idsCsv) {
    var ids = String(idsCsv).split(",");
    for (var i = 0; i < ids.length; i++) {
        try {
            var d = new ActionDescriptor();
            var r = new ActionReference();
            r.putIdentifier(cTID('Lyr '), parseInt(ids[i], 10));
            d.putReference(cTID('null'), r);
            if (i > 0) d.putEnumerated(sTID('selectionModifier'), sTID('selectionModifierType'), sTID('addToSelection'));
            d.putBoolean(cTID('MkVs'), false);
            executeAction(cTID('slct'), d, DialogModes.NO);
        } catch (e) {}
    }
    return "OK";
}
