@echo off
chcp 65001 >nul
title Inikas Installer
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.mustapha.inikas"
echo Installing Inikas to: %DEST%
if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%"
xcopy "%~dp0com.mustapha.inikas\*" "%DEST%\" /e /i /y /q >nul
for %%v in (8 9 10 11 12) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
echo.
echo Done. Restart Photoshop, then: Window ^> Extensions (legacy) ^> انعكاس — Inikas
pause
