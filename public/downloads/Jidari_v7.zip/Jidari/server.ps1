﻿$ErrorActionPreference = 'Stop'
$root = (Get-Location).Path
$port = 8765
$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Parse('127.0.0.1'), $port)
try {
  $listener.Start()
  Start-Process "http://127.0.0.1:$port/index.html"
  Write-Host "Jidari is running at http://127.0.0.1:$port/index.html" -ForegroundColor Green
  Write-Host "Keep this window open while using the app. Press Ctrl+C to stop." -ForegroundColor Yellow
  while ($true) {
    $client = $listener.AcceptTcpClient()
    try {
      $stream = $client.GetStream()
      $stream.ReadTimeout = 5000
      $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::ASCII, $false, 1024, $true)
      $requestLine = $reader.ReadLine()
      if (-not $requestLine) { $client.Close(); continue }
      while (($h = $reader.ReadLine()) -ne $null -and $h -ne '') { }
      $parts = $requestLine.Split(' ')
      $urlPath = [Uri]::UnescapeDataString(($parts[1] -split '\?')[0]).TrimStart('/')
      if ([string]::IsNullOrWhiteSpace($urlPath)) { $urlPath = 'index.html' }
      $full = [IO.Path]::GetFullPath((Join-Path $root $urlPath))
      if (-not $full.StartsWith($root, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $full -PathType Leaf)) {
        $status = '404 Not Found'; $bytes = [Text.Encoding]::UTF8.GetBytes('Not Found'); $type = 'text/plain; charset=utf-8'
      } else {
        $bytes = [IO.File]::ReadAllBytes($full)
        $ext = [IO.Path]::GetExtension($full).ToLowerInvariant()
        $type = switch ($ext) { '.html' {'text/html; charset=utf-8'} '.js' {'text/javascript; charset=utf-8'} '.css' {'text/css; charset=utf-8'} '.json' {'application/json'} '.png' {'image/png'} '.jpg' {'image/jpeg'} '.jpeg' {'image/jpeg'} '.webp' {'image/webp'} '.glb' {'model/gltf-binary'} '.hdr' {'application/octet-stream'} '.txt' {'text/plain; charset=utf-8'} default {'application/octet-stream'} }
        $status = '200 OK'
      }
      $header = "HTTP/1.1 $status`r`nContent-Type: $type`r`nContent-Length: $($bytes.Length)`r`nAccess-Control-Allow-Origin: *`r`nConnection: close`r`nCache-Control: no-store`r`n`r`n"
      $headBytes = [Text.Encoding]::ASCII.GetBytes($header)
      $stream.Write($headBytes, 0, $headBytes.Length)
      if ($bytes.Length -gt 0) { $stream.Write($bytes, 0, $bytes.Length) }
      $stream.Flush()
    } catch { }
    finally { $client.Close() }
  }
} finally { $listener.Stop() }
